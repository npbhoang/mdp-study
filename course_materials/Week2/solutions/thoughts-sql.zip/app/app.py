from flask import Flask, session, render_template, request, redirect, url_for
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)

app.secret_key = b'_5#yfasQ8sansaxec/][#1'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///app.db'

db = SQLAlchemy(app)

class Vote(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    person_id = db.Column(db.Integer, db.ForeignKey('person.id'))
    thought_id = db.Column(db.Integer, db.ForeignKey('thought.id'))

class Person(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(50), unique=True)
    password = db.Column(db.String(50))
    created = db.relationship('Thought', backref='createdBy')
    voted = db.relationship('Vote', backref='voter')

class Thought(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    content = db.Column(db.String(500))
    person_id = db.Column(db.Integer, db.ForeignKey('person.id'))
    votedBy = db.relationship('Vote', backref='votee')

with app.app_context():
    db.create_all()

@app.route('/')
def index():
    thoughts=Thought.query.all()
    return render_template('index.html', table=thoughts)


def check(u,p):
    return Person.query.filter_by(name=u,password=p).first()!=None
        
def caller(u):
    return Person.query.filter_by(name=u).first()
        
def target(i):
    return Thought.query.get(i)

@app.route('/login', methods=['POST'])
def login():
    user = request.form["username"]
    passw = request.form["password"]
    if check(user,passw): 
        session["caller"] = user
        return redirect(url_for('index'))
    else:
        return render_template('login.html', wrong_pass=True)


@app.route('/logout', methods=['POST'])
def logout():
    session.pop('caller', None)
    return redirect(url_for('index'))
    



@app.route('/register', methods=['POST'])
def register():
    user = request.form["username"]
    passw = request.form["password"]
    if user != "" and passw != "":
        if caller(user)==None: 
            u = Person(name=user,password=passw)
            db.session.add(u)
            db.session.commit()
            session["caller"] = u.name
            return redirect(url_for('index'))
        else:
            return render_template('login.html', wrong_username=True)
    else:
        return render_template('login.html', invalid_input=True)


@app.route('/add_thought', methods=['POST'])
def add_thought():
    if "caller" in session:
        content = request.form["thought"]
        if content != "":
            t = Thought(content=content)
            t.createdBy = caller(session["caller"])
            db.session.add(t)
            db.session.commit()
            return redirect(url_for('index'))
        else:
            thoughts = Thought.query.all()
            return render_template('index.html', table=thoughts, invalid_input=True)
    else:
        return render_template('login.html')


@app.route('/delete_thought')
def delete_thought():
    if "caller" in session:
        id = request.args["id"]
        try: 
            i = int(id)
            t = target(i)
            if t != None:
                db.session.delete(t)
                db.session.commit()
            return redirect(url_for('index'))
        except:
            return redirect(url_for('index'))
    else:
        return render_template('login.html')


@app.route('/vote_thought')
def vote_thought():
    if "caller" in session:
        id = request.args["id"]
        try: 
            i = int(id)
            t = target(i)
            c = caller(session["caller"])
            if t != None and c != None:
                v = Vote(voter=c, votee=t)
                db.session.add(v)
                db.session.commit()
            return redirect(url_for('index'))
        except:
            return redirect(url_for('index'))
    else:
        return render_template('login.html')




