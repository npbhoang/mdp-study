This example is run interactively in a terminal (to run `python`, `sqlite3`, etc.)
rather than automatically launching Flask. See `lab2.pdf` for the exercise.

To open a terminal in the Docker container, call:
```bash
    docker-compose run --rm flask bash
```

Inside the container, run an example with, e.g.:
```bash
    python sql.py        # or: python user.py
```
