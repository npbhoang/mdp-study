from flask import Flask
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///app.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)

# votes = db.Table('votes',
#     db.Column('person_id', db.Integer, db.ForeignKey('person.id')),
#     db.Column('thought_id', db.Integer, db.ForeignKey('thought.id'))
# )

class Vote(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    person_id = db.Column(db.Integer, db.ForeignKey('person.id'))
    thought_id = db.Column(db.Integer, db.ForeignKey('thought.id'))


class Person(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(50))
    created = db.relationship('Thought', backref='createdBy')
    # voted = db.relationship('Thought', secondary=votes, backref='votedBy')
    voted = db.relationship('Vote', backref='voter')

    def __repr__(self):
        return f'<Person id:{self.id} name:{self.name}>'
   

class Thought(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    content = db.Column(db.String(500))
    person_id = db.Column(db.Integer, db.ForeignKey('person.id'))
    votedBy = db.relationship('Vote', backref='votee')

    def __repr__(self):
        end = '...\'>' if len(self.content) > 10 else '\'>'
        return f'<Thought id:{self.id} content:\'{self.content[:10]}' + end 

with app.app_context():
    db.create_all()

    alice = Person(name='Alice')
    bob = Person(name='Bob')
    t1 = Thought(content='I think, therefore I am.', createdBy=alice)
    t2 = Thought(content='Cogito, ergo sum',createdBy=bob)
    db.session.add_all([alice,bob])
    db.session.add_all([t1,t2])
    db.session.commit()

    # alice.voted.append(t2)
    # alice.voted.append(t2)
    # print(alice.voted)
    # db.session.commit()
    # print(alice.voted)
    # ids = db.session.query(Thought.id).filter((votes.c.person_id==alice.id) & (votes.c.thought_id==Thought.id)).all()
    # print([Thought.query.get(i) for i in ids])


    v1 = Vote(voter=alice, votee=t1)
    v2 = Vote(voter=alice, votee=t1)
    db.session.add_all([v1,v2])
    db.session.commit()
    print([x.votee for x in alice.voted])

