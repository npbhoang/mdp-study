from flask import Flask, render_template_string
from flask_sqlalchemy import SQLAlchemy
from flask_user import login_required, UserManager, UserMixin, current_user


app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///app.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['USER_APP_NAME'] = "Flask-User Mini-App"
app.config['USER_ENABLE_EMAIL'] = False      
app.config['USER_ENABLE_USERNAME'] = True    
app.config['USER_REQUIRE_RETYPE_PASSWORD'] = False
app.config['SECRET_KEY'] = '_5#yfasQ8sansaxec/][#18QUIbI6IMA'

db = SQLAlchemy(app)

class Person(db.Model,UserMixin):
    id = db.Column(db.Integer, primary_key=True)
    active = db.Column('is_active', db.Boolean(), nullable=False, server_default='1')
    username = db.Column(db.String(100, collation='NOCASE'), nullable=False, unique=True)
    password = db.Column(db.String(255), nullable=False, server_default='')

with app.app_context():
    db.create_all()

user_manager = UserManager(app, db, Person)

# The Home page is accessible to anyone
@app.route('/')
def home_page():
    return render_template_string('''
{% extends "flask_user_layout.html" %}
{% block content %}
    <h2>Home page</h2>
    <p><a href={{ url_for('user.register') }}>Register</a></p>
    <p><a href={{ url_for('user.login') }}>Sign in</a></p>
    <p><a href={{ url_for('home_page') }}>Home page</a></p>
    <p><a href={{ url_for('member_page') }}>Member page</a></p>
    <p><a href={{ url_for('user.logout') }}>Sign out</a></p>
{% endblock %}
''')

# The Members page is only accessible to authenticated users via the @login_required decorator
@app.route('/members')
@login_required    
def member_page():
    return render_template_string('''
{% extends "flask_user_layout.html" %}
{% block content %}
    <h2>Members page</h2><p>Hello, {{ username }}</p>
    <p><a href={{ url_for('home_page') }}>Home page</a></p>
    <p><a href={{ url_for('user.logout') }}>Sign out</a></p>
{% endblock %}
''', username=current_user.username)



