from ocl.ocl import OCLTerm

class Web(OCLTerm):
    def __init__(self, domain):
        self.domain = domain
        self.pages = set()

    def add_page(self, page):
        self.pages.add(page)
        page.web = self

    def __repr__(self):
        return f"Web(domain={self.domain})"

class Webpage(OCLTerm):
    def __init__(self, name, web):
        self.name = name
        self.categories = set()
        self.articles = set()
        self.web = web
        web.add_page(self)

    def __repr__(self):
        return f"Webpage(name={self.name}, web={self.web.domain})"

    def add_category(self, category):
        self.categories.add(category)
        category.webpage = self

    def add_article(self, article):
        self.articles.add(article)
        article.webpage = self
        
class Category(OCLTerm):
    def __init__(self, name, webpage):
        self.name = name
        self.webpage = webpage
        webpage.add_category(self)
        self.articles = set()

    def add_article(self, article):
        self.articles.add(article)
        article.category.add(self)

    def __repr__(self):
        return f"Category(name={self.name}, webpage={self.webpage.name})"

class Article(OCLTerm):
    def __init__(self, title, webpage):
        self.title = title
        self.webpage = webpage
        webpage.add_article(self)
        self.category = set()

    def add_category(self, category):
        self.category.add(category)
        category.add_article(self)

    def __repr__(self):
        return f"Article(title={self.title}, webpage={self.webpage.name})"