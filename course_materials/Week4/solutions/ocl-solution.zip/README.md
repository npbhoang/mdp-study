# OCL Lab — Solutions (Week 4)

This lab uses the **OCL-py** library to parse and evaluate Object Constraint Language
(OCL) expressions over a small Python data model. The exercise is described in `lab4.pdf`.

The `playground` service (see `docker-compose.yml`) builds a container with `ocl-py`
pre-installed and live-mounts the `app/` directory, which contains the example data
model `app/model.py` and the reference solutions `app/solution.py`.

## Requirements
- Docker

## Usage
1. Build the image and open an interactive shell in the container:
   ```bash
   docker compose run --rm playground bash
   ```
   (The Python virtual environment with `ocl-py` installed is activated automatically.)

2. Inside the container, run the example data model or the reference solutions:
   ```bash
   python model.py
   python solution.py
   ```

3. Edit `app/model.py` on your host (changes are live-mounted) to define your own
   classes and evaluate OCL expressions, for example:
   ```python
   from ocl.ocl import eval_ocl
   print(eval_ocl("let x = Set{0, 1..5} in x->select(e | e > 0)"))
   ```

See `lab4.pdf` for the full exercise.
