from ocl.ocl import eval_ocl
from model import Web, Webpage, Category, Article
import model

# Domain and Webpages
d = Web("MyDomain")
p1 = Webpage("CNET", d)
p2 = Webpage("CNN", d)

# Catergories and Articles
c1 = Category("Tech", p1)
c2 = Category("News", p1)
c3 = Category("Politics", p2)
c4 = Category("Sports", p2)
c5 = Category("Health", p2)

a1 = Article("Article 1", p1)
a2 = Article("Article 2", p1)
a3 = Article("Article 3", p1)
a4 = Article("Article 4", p2)
a5 = Article("Article 5", p2)
a6 = Article("Article 6", p2)
a7 = Article("Article 7", p2)
a8 = Article("Article 8", p2)

# Adding articles to categories
c1.add_article(a1)
c1.add_article(a3)
c2.add_article(a2)
c2.add_article(a3)

c3.add_article(a6)
c3.add_article(a8)

c4.add_article(a5)
c4.add_article(a7)
c4.add_article(a8)

# TASK SOLUTIONS
Q1 = "self"
Q2 = "self.pages"
Q3 = "self.pages.name"
Q4 = "self.pages.name->asSet()"
Q5 = "model::Webpage.allInstances().name->asSet()"
Q6 = "model::Category.allInstances()->size()"
Q7 = "model::Category.allInstances()->select(c | c.articles->size() = 0)"
Q8 = "model::Article.allInstances()->select(a | a.category->size() > 1)"
Q9 = "model::Article.allInstances()->select(a | a.category.name->any(c|c='Politics' or c='News')<>null)"
Q10 = "model::Article.allInstances()->select(a | a.category.name->includesAll(Set{'Tech','News'}))"
C1 = "model::Webpage.allInstances()->forAll(p|model::Webpage.allInstances()->forAll(q | (p<>q) implies p.articles->intersection(q.articles)->isEmpty() ))"
C2 = "(model::Web.allInstances().pages->collect(p | p.articles.category->asSet())->flatten()->asSet() - model::Web.allInstances().pages->collect(p | p.categories)->flatten()->asSet())->isEmpty()"

print("Q1:", eval_ocl(Q1, self=d))
print("Q2:", eval_ocl(Q2, self=d))
print("Q3:", eval_ocl(Q3, self=d))
print("Q4:", eval_ocl(Q4, self=d))
print("Q5:", eval_ocl(Q5))
print("Q6:", eval_ocl(Q6))
print("Q7:", eval_ocl(Q7))
print("Q8:", eval_ocl(Q8))
print("Q9:", eval_ocl(Q9))
print("Q10:", eval_ocl(Q10))
print("C1:", eval_ocl(C1))
print("C2:", eval_ocl(C2))


