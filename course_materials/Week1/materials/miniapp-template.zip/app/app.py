
from flask import Flask

app = Flask(__name__)


##########################################
# Step 1: Basic app
@app.route("/")
def main():
    return "Hello world!"


# ##########################################
# # Step 2: Multiple routes
# @app.route("/")
# def main():
#     return "Main menu"

# @app.route("/hello")
# def hello():
#     return "Hello world!"


# ##########################################
# # Step 3: Parameters and converter types
# @app.route("/")
# def main():
#     return "Main menu"

# @app.route("/hello/<name>")
# def hello(name="world"):
#     return f"Hello {name}!"

# # other converter types: string, int, float, path, uuid
# @app.route("/hello/<int:number>")
# def bye(number=0):
#     return f"Hello int {number}!"


# ##########################################
# # Step 4: Redirect and building URLs

# from flask import redirect, url_for

# @app.route("/")
# def main():
#     return "Main menu"

# @app.route("/hello/<name>")
# def hello(name="world"):
#     return f"Hello {name}!"

# # url_for: function name + vararg of named parameters
# @app.route("/hello/<int:number>")
# def bye(number=0):
#     if number == 0:
#         return redirect(url_for('hello',name="zero"))
#     print(url_for('main'))
#     # print(url_for('hello'))
#     print(url_for('hello', name="John Doe"))
#     print(url_for('bye', number=1))
#     return f"Hello int {number}!"



# ##########################################
# # Step 5: HTTP methods and request

# from flask import request

# @app.route("/")
# def main():
#     return '''<form action='/hello' method='post'>
#               <input type='text' name='name'>
#               <input type="submit" value="Submit">
#               </form>'''

# # By default, a route only answers to GET requests
# # You can use the methods argument of the route decorator to tell it to use other HTTP methods
# @app.route("/hello", methods=['GET', 'POST'])
# def hello():
#     # Data a sent to the app is provided by the global request object
#     # It is actually a proxy to request objects that are context-local, and hence threadsafe
#     if request.method == 'POST':        # The current method is available via the method attribute 
#         return "POST! " + request.form["name"] # To access POST (or PUT) data use the form attribute
#     else:    
#         return "GET! " + request.args["name"] # To access GET data use the form attribute

# # You can also separate views for different methods into different functions
# @app.get('/login')
# def login_get():
#     return "show_the_login_form"

# @app.post('/login')
# def login_post():
#     return "do_the_login"



# ##########################################
# # Step 6: Sessions

# from flask import session, request, redirect, url_for

# app.secret_key = b'_5#yfasQ8sansaxec/][#1'

# # The session object is a key-value map that allows storing 
# # per-user information. 
# # This is implemented using cookies: if a user's browser
# # provides a previously obtained cookie, the session object
# # will contain the key-value bindings previously set for that
# # user. Flask uses secret_key 
# # to sign the cookies. This means is that the user could 
# # look at the contents of a cookie but cannot modify it.

# @app.route('/')
# def main():
#     # Check if user has a session (i.e., their browser provided a valid cookie)
#     if 'username' in session:
#         return f'Logged in as {session["username"]}'
#     return 'You are not logged in'

# @app.route('/login', methods=['GET', 'POST'])
# def login():
#     if request.method == 'POST':
#         # Set ('username' -> request.form['username']) binding to session for the current user
#         session['username'] = request.form['username']
#         return redirect(url_for('main'))
#     return '''
#         <form method="post">
#             <p><input type='text' name='username'>
#             <p><input type='submit' value='Login'>
#         </form>
#         '''

# @app.route('/logout')
# def logout():
#     # remove the username from the session if it's there
#     session.pop('username', None)
#     return redirect(url_for('main'))
    



##########################################
# Step 7: Templates

# from flask import render_template, session, request, redirect, url_for

# app.secret_key = b'_5#yfasQ8sansaxec/][#1'

# @app.route('/')
# def main():
#     if 'username' in session:
#         return render_template('main.html', username=session['username'])
#     return render_template('auth.html', wrong_pass=False)

# credentials = {
#     "admin" : "admin",
#     "alice" : "secret",
#     "bob"   : "69DRcmFc1vFJN1T"
# }

# def check(username, password):
#     return username in credentials and password == credentials[username]

# @app.route('/login', methods=['GET', 'POST'])
# def login():
#     if request.method == 'POST':
#         if check(request.form['username'],request.form['password']):
#             session['username'] = request.form['username']
#             return redirect(url_for('main'))
#         else: 
#             return render_template('auth.html', wrong_pass=True)
#     return render_template('auth.html')

# @app.route('/logout')
# def logout():
#     session.pop('username', None)
#     return redirect(url_for('main'))
    
