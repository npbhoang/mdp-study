from flask import Flask, session, render_template, request, redirect, url_for

app = Flask(__name__)

app.secret_key = b'_5#yfasQ8sansaxec/][#1'


class Person:
    def __init__(self,name,password) -> None:
        self._name = name
        self._password = password
        self._created = set()
        self._voted = []

    @property
    def name(self):
        return self._name

    @name.setter
    def name(self,n):
        self._name = n

    @property
    def password(self):
        return self._password

    @password.setter
    def password(self,p):
        self._password = p

    @property
    def created(self):
        return self._created

    def addcreated(self,t):
        self._created.add(t)
        t._createdBy = self

    def removecreated(self,t):
        self._created.remove(t)
        del t._createdBy

    @property
    def voted(self):
        return self._voted

    def addvoted(self,t):
        self._voted.append(t)
        t._votedBy.append(self)

    def removevoted(self,t):
        self._voted.remove(t)
        t._votedBy.remove(self)

    # def __del__(self):
    #     for t in self.created:
    #         t._createdBy = None
    #     self._created.clear()

    #     for t in self.voted:
    #         t._votedBy.remove(self)
        
    #     self._voted.clear()
        
            
        

class Thought:
    ids = 0
    def __init__(self,content) -> None:
        self._id = Thought.ids
        Thought.ids = Thought.ids+1
        self._content = content
        self._createdBy = None
        self._votedBy = []
    
    @property
    def id(self):
        return self._id

    @property
    def content(self):
        return self._content

    @content.setter
    def content(self,c):
        self._content = c

    @property
    def createdBy(self):
        return self._createdBy

    @createdBy.setter
    def createdBy(self,p):
        self._createdBy = p
        p._created.add(self)

    @createdBy.deleter
    def createdBy(self):
        if self._createdBy != None:
            self._createdBy._created.remove(self)
        del self._createdBy

    @property
    def votedBy(self):
        return self._votedBy

    def addvotedBy(self,p):
        self._votedBy.append(p)
        p._voted.append(self)

    def removevotedBy(self,p):
        self._votedBy.remove(p)
        p._voted.remove(self)

    # def __del__(self):
    #     del self.createdBy
    #     self.votedBy.clear()


persons = set()    
thoughts = []



@app.route('/')
def index():
    return render_template('index.html', table=thoughts)


def check(u,p):
    return len({x for x in persons if x.name == u and x.password == p})>0
        
def caller(u):
    ps = {x for x in persons if x.name == u}
    if len(ps) == 0:
        return None
    else:
        return ps.pop()
        
def target(i):
    ts = [x for x in thoughts if x.id == i]
    if len(ts) == 0:
        return None
    else:
        return ts.pop()


@app.route('/login', methods=['POST'])
def login():
    #validate input
    user = request.form["username"]
    passw = request.form["password"]
    if check(user,passw): #login check
        session["caller"] = user
        return redirect(url_for('index'))
    else:
        return render_template('login.html', wrong_pass=True)


@app.route('/logout', methods=['POST'])
def logout():
    session.pop('caller', None)
    return redirect(url_for('index'))
    



@app.route('/register', methods=['POST'])
def register():
    #validate input
    user = request.form["username"]
    passw = request.form["password"]
    if user != "" and passw != "": #form check
        if caller(user)==None: #username check
            u = Person(user,passw)
            persons.add(u)
            session["caller"] = u.name
            return redirect(url_for('index'))
        else:
            return render_template('login.html', wrong_username=True)
    else:
        return render_template('login.html', invalid_input=True)


@app.route('/add_thought', methods=['POST'])
def add_thought():
    if "caller" in session:  
        #validate input
        content = request.form["thought"]
        if content != "":
            t = Thought(content)
            t.createdBy = caller(session["caller"])
            thoughts.append(t)
            return redirect(url_for('index'))
        else:
            return render_template('index.html', table=thoughts, invalid_input=True)
    else:
        return render_template('login.html')


@app.route('/delete_thought')
def delete_thought():
    if "caller" in session:  
        id = request.args["id"]
        try: 
            i = int(id)
            t = target(i)
            if t != None:
                thoughts.remove(t)
                # del t
            return redirect(url_for('index'))
        except:
            return redirect(url_for('index'))
    else:
        return render_template('login.html')


@app.route('/vote_thought')
def vote_thought():
    if "caller" in session:  
        id = request.args["id"]
        try: 
            i = int(id)
            t = target(i)
            c = caller(session["caller"])
            if t != None and c!=None:
                t.addvotedBy(c)
            return redirect(url_for('index'))
        except:
            return redirect(url_for('index'))
    else:
        return render_template('login.html')




