# Copyright (c) 2023 All Rights Reserved
# Generated code

from application import app
from flask_sqlalchemy import SQLAlchemy
from flask_user import UserMixin, current_user
from instrumentation import Secure
from stm import messageBoardSecurityModel
from ptm import messageBoardPrivacyModel
from ocl.ocl import OCLTerm
from sqlalchemy import UniqueConstraint

db = SQLAlchemy()

# ROLES
UNAUTHENTICATED_ROLE = "VISITOR"
VISITOR = "VISITOR"
NORMAL = "NORMAL"
ADMIN = "ADMIN"
# NONE and SYSTEM roles are not needed explicitly

# PURPOSES



with app.app_context():

    # Associations
    consentedpurposes = db.Table('consentedpurposes',
            db.Column('consent_id', db.Integer, db.ForeignKey('consent.id'), nullable=False, primary_key=True),
            db.Column('purpose_id', db.Integer, db.ForeignKey('purpose.id'), nullable=False, primary_key=True)
    )
    
    class association_messageowner_messages(db.Model):
            
        id = db.Column(db.Integer, primary_key=True)
        messages_id = db.Column(db.Integer(), db.ForeignKey('message.id'), unique=True)
        messageOwner_id = db.Column(db.Integer(), db.ForeignKey('person.id'))
        messages = db.relationship('Message', back_populates='association_messageowner_messages', uselist=False)
        messageOwner = db.relationship('Person', back_populates='association_messageowner_messages', uselist=False)
    
    
    class association_replies_replyowner(db.Model):
            
        id = db.Column(db.Integer, primary_key=True)
        replies_id = db.Column(db.Integer(), db.ForeignKey('reply.id'), unique=True)
        replyOwner_id = db.Column(db.Integer(), db.ForeignKey('person.id'))
        replies = db.relationship('Reply', back_populates='association_replies_replyowner', uselist=False)
        replyOwner = db.relationship('Person', back_populates='association_replies_replyowner', uselist=False)
    
    
    class association_message_messagereplies(db.Model):
            
        id = db.Column(db.Integer, primary_key=True)
        messageReplies_id = db.Column(db.Integer(), db.ForeignKey('reply.id'), unique=True)
        message_id = db.Column(db.Integer(), db.ForeignKey('message.id'))
        messageReplies = db.relationship('Reply', back_populates='association_message_messagereplies', uselist=False)
        message = db.relationship('Message', back_populates='association_message_messagereplies', uselist=False)
    
    

    # ENTITIES
    
    # User class
    @Secure(messageBoardSecurityModel,messageBoardPrivacyModel)
    class Person(db.Model,UserMixin,OCLTerm):

        #Attributes
        id = db.Column(db.Integer, primary_key=True)
        active = db.Column('is_active', db.Boolean(), nullable=False, server_default='1')
        roles = db.relationship('Role', secondary='user_roles')
        username = db.Column(db.String(100, collation='NOCASE'), nullable=False, unique=True)
        password = db.Column(db.String(255), nullable=False, server_default='')
        name = db.Column(db.String(100, collation="NOCASE"))
        
        # Association ends
        association_messageowner_messages = db.relationship('association_messageowner_messages', cascade="all, delete-orphan", back_populates='messageOwner')
        
        @property
        def messages(self):    
            return messagesList(self, [x.messages for x in self.association_messageowner_messages]) 
        
        association_replies_replyowner = db.relationship('association_replies_replyowner', cascade="all, delete-orphan", back_populates='replyOwner')
        
        @property
        def replies(self):    
            return repliesList(self, [x.replies for x in self.association_replies_replyowner]) 
        
        @property
        def role(self):
            return self.roles[0]
        
        @role.setter
        def role(self,r):
            self.roles = [r]
        
        @property
        def is_authenticated(self):
            return True
        
        def __eq__(self, obj):
            return isinstance(obj,UserMixin) and self.id == obj.id
        
        def __delete__(self, db):
            db.session.delete(self)  
        

    class Role(db.Model,OCLTerm):
        id = db.Column(db.Integer(), primary_key=True)
        name = db.Column(db.String(50), unique=True)

        @staticmethod
        def getAuthenticatedRoles():
            return Role.query.filter(Role.name != UNAUTHENTICATED_ROLE).all()

        @classmethod
        def _get_role(cls, role_name):
            return cls.query.filter_by(name=role_name).first()
            
        @classmethod
        @property
        def VISITOR(cls):
            return cls._get_role('VISITOR')

        @classmethod
        @property
        def NORMAL(cls):
            return cls._get_role('NORMAL')

        @classmethod
        @property
        def ADMIN(cls):
            return cls._get_role('ADMIN')

        
        
    class UserRoles(db.Model):
        id = db.Column(db.Integer(), primary_key=True)
        user_id = db.Column(db.Integer(), db.ForeignKey('person.id'), unique=True)
        role_id = db.Column(db.Integer(), db.ForeignKey('role.id'))
        
    class messagesList(list):
        
        def __init__(self,this):
            self._this = this
            super().__init__()
        
        def __init__(self,this, __iterable):
            self._this = this
            super().__init__(__iterable)
        
        def append(self,e):
            v = association_messageowner_messages(messageOwner=self._this,messages=e)
            db.session.add(v)
            super().append(e)
        
        def remove(self,e):
            super().remove(e)
            v = association_messageowner_messages.query.filter_by(messageOwner=self._this,messages=e).first()
            db.session.delete(v)
    class repliesList(list):
        
        def __init__(self,this):
            self._this = this
            super().__init__()
        
        def __init__(self,this, __iterable):
            self._this = this
            super().__init__(__iterable)
        
        def append(self,e):
            v = association_replies_replyowner(replyOwner=self._this,replies=e)
            db.session.add(v)
            super().append(e)
        
        def remove(self,e):
            super().remove(e)
            v = association_replies_replyowner.query.filter_by(replyOwner=self._this,replies=e).first()
            db.session.delete(v)
    
    
    
    
    @Secure(messageBoardSecurityModel,messageBoardPrivacyModel)
    class Message(db.Model,OCLTerm):

        # Attributes
        id = db.Column(db.Integer, primary_key=True)
        title = db.Column(db.String(100, collation="NOCASE"))
        text = db.Column(db.String(100, collation="NOCASE"))
        
        # Association ends
        association_messageowner_messages = db.relationship('association_messageowner_messages', cascade="all, delete-orphan", back_populates='messages', uselist=False)
        @property
        def messageOwner(self):
            return self.association_messageowner_messages.messageOwner if self.association_messageowner_messages else None

        @messageOwner.setter
        def messageOwner(self, value):
            if self.association_messageowner_messages:
                self.association_messageowner_messages.messageOwner = value
            else:
                v = association_messageowner_messages(messages=self,messageOwner=value)
                db.session.add(v)
            
        association_message_messagereplies = db.relationship('association_message_messagereplies', cascade="all, delete-orphan", back_populates='message')
        @property
        def messageReplies(self):
            
            return messageRepliesList(self, [x.messageReplies for x in self.association_message_messagereplies]) 
            
        
    
        def __delete__(self, db):
            db.session.delete(self)  
    
    class messageOwnerList(list):
        
        def __init__(self,this):
            self._this = this
            super().__init__()
        
        def __init__(self,this, __iterable):
            self._this = this
            super().__init__(__iterable)
        
        def append(self,e):
            v = association_messageowner_messages(messages=self._this,messageOwner=e)
            db.session.add(v)
            super().append(e)
        
        def remove(self,e):
            super().remove(e)
            v = association_messageowner_messages.query.filter_by(messages=self._this,messageOwner=e).first()
            db.session.delete(v)
    class messageRepliesList(list):
        
        def __init__(self,this):
            self._this = this
            super().__init__()
        
        def __init__(self,this, __iterable):
            self._this = this
            super().__init__(__iterable)
        
        def append(self,e):
            v = association_message_messagereplies(message=self._this,messageReplies=e)
            db.session.add(v)
            super().append(e)
        
        def remove(self,e):
            super().remove(e)
            v = association_message_messagereplies.query.filter_by(message=self._this,messageReplies=e).first()
            db.session.delete(v)
    
    
    
    
    
    @Secure(messageBoardSecurityModel,messageBoardPrivacyModel)
    class Reply(db.Model,OCLTerm):

        # Attributes
        id = db.Column(db.Integer, primary_key=True)
        text = db.Column(db.String(100, collation="NOCASE"))
        
        # Association ends
        association_replies_replyowner = db.relationship('association_replies_replyowner', cascade="all, delete-orphan", back_populates='replies', uselist=False)
        @property
        def replyOwner(self):
            return self.association_replies_replyowner.replyOwner if self.association_replies_replyowner else None

        @replyOwner.setter
        def replyOwner(self, value):
            if self.association_replies_replyowner:
                self.association_replies_replyowner.replyOwner = value
            else:
                v = association_replies_replyowner(replies=self,replyOwner=value)
                db.session.add(v)
            
        association_message_messagereplies = db.relationship('association_message_messagereplies', cascade="all, delete-orphan", back_populates='messageReplies', uselist=False)
        @property
        def message(self):
            return self.association_message_messagereplies.message if self.association_message_messagereplies else None

        @message.setter
        def message(self, value):
            if self.association_message_messagereplies:
                self.association_message_messagereplies.message = value
            else:
                v = association_message_messagereplies(messageReplies=self,message=value)
                db.session.add(v)
            
        
    
        def __delete__(self, db):
            db.session.delete(self)  
    
    class replyOwnerList(list):
        
        def __init__(self,this):
            self._this = this
            super().__init__()
        
        def __init__(self,this, __iterable):
            self._this = this
            super().__init__(__iterable)
        
        def append(self,e):
            v = association_replies_replyowner(replies=self._this,replyOwner=e)
            db.session.add(v)
            super().append(e)
        
        def remove(self,e):
            super().remove(e)
            v = association_replies_replyowner.query.filter_by(replies=self._this,replyOwner=e).first()
            db.session.delete(v)
    class messageList(list):
        
        def __init__(self,this):
            self._this = this
            super().__init__()
        
        def __init__(self,this, __iterable):
            self._this = this
            super().__init__(__iterable)
        
        def append(self,e):
            v = association_message_messagereplies(messageReplies=self._this,message=e)
            db.session.add(v)
            super().append(e)
        
        def remove(self,e):
            super().remove(e)
            v = association_message_messagereplies.query.filter_by(messageReplies=self._this,message=e).first()
            db.session.delete(v)
    
    
    
    
    
    
    
    
    
    
    

        
    
    class Purpose(db.Model,OCLTerm):
        id = db.Column(db.Integer(), primary_key=True)
        name = db.Column(db.String(50), unique=True)
        parent_id = db.Column(db.Integer, db.ForeignKey('purpose.id'))
        subpurposes = db.relationship('Purpose')

        def get_subpurposes_names(self):
            ret = []
            for sp in self.subpurposes:
                ret.append(sp.name)
                ret.extend(sp.get_subpurposes_names())  # Recursively get sub-purpose names
            return ret

        # consents = db.relationship('Consent', secondary=consentedpurposes, lazy='subquery',
        # back_populates='purposes')

        def __hash__(self):
            return hash(self.id)
        
    class PersonalData(db.Model,OCLTerm):
        id = db.Column(db.Integer(), primary_key=True)
        resource = db.Column(db.String(100))
        subresource = db.Column(db.String(100))
        __table_args__ = (
            UniqueConstraint('resource', 'subresource', name='resource_subresource_uc'),
        )

    class Consent(db.Model,OCLTerm):
        id = db.Column(db.Integer(), primary_key=True)
        user_id = db.Column(db.Integer, db.ForeignKey('person.id'), nullable=False)
        user = db.relationship('Person', foreign_keys=user_id, backref='consents')
        data_id = db.Column(db.Integer, db.ForeignKey('personal_data.id'), nullable=False)
        data = db.relationship('PersonalData', foreign_keys=data_id)
        purposes = db.relationship('Purpose', secondary=consentedpurposes, lazy='subquery')#, back_populates='consents')

        def __hash__(self):
            return hash(self.id)
        

