from model import Action, Constraint
from enum import auto, Enum
from privacy_model import PrivacyModel


class messageBoardPrivacyModel(PrivacyModel):

    # Extensible model (default: nothing declared)

    class Purpose(Enum):
        
        pass
        

    personaldata = [
        ]
        
    model = []

messageBoardPrivacyModel.validate()