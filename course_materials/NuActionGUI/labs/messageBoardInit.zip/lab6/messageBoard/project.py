# Copyright (c) 2023 All Rights Reserved

from flask import render_template, redirect, url_for
from flask_user import current_user
from dtm import Message, Reply, Person, Role
from app import db

def main(request):
    messages = Message.query.all()
    return render_template("main.html",user=current_user,messages=messages)

def createMessageWindow(request):
    users = Person.query.all()
    return render_template("createMessageWindow.html", users=users, invalid_input=False)

def createMessage(request):
    title = request.form["messageTitle"]
    text = request.form["messageText"]
    if title != "" and text != "":
        m = Message()
        m.messageOwner = current_user
        m.title = title
        m.text = text
        db.session.add(m)
        db.session.commit()
        return redirect(url_for('main')) 
    else:
        users = Person.query.all()
        return render_template('createMessageWindow.html', users=users, invalid_input=True)

def openMessage(request):
    id = request.args["id"]
    i = int(id)
    m = Message.query.get(i)
    return render_template('viewMessageWindow.html', message=m)

def modifyMessage(request):
    title = request.form["messageTitle"]
    text = request.form["messageText"]
    id = request.form["messageId"]

    i = int(id)
    m = Message.query.get(i)
    if title != "" and text != "":
        m.title = title
        m.text = text
        db.session.add(m)
        db.session.commit()
        return redirect(url_for('main')) 
    else:    
        users = Person.query.all() 
        shared_with = [user.id for user in m.sharedWith]
        return render_template('editMessageWindow.html', message=m, users=users, invalid_input=True)

def deleteMessage(request):
    id = request.args["id"]
    i = int(id)
    m = Message.query.get(i)
    m.__delete__(db)
    db.session.commit()
    return redirect(url_for('main')) 

def createReply(request):
    messageId = request.form["messageId"]
    content = request.form["replyContent"]
    i = int(messageId)
    m = Message.query.get(i)
    if content != "":
        r = Reply()
        r.replyOwner = current_user
        r.message = m
        r.text = content
        db.session.add(r)
        db.session.commit()
        return render_template('viewMessageWindow.html', message=m)
    else:
        return render_template('createReplyWindow.html', messageId=messageId, invalid_input=True)

def deleteReply(request):
    rid = request.args["rid"]
    replyId = int(rid)
    r = Reply.query.get(replyId)
    r.__delete__(db)
    db.session.commit()

    mid = request.args["mid"]
    messageId = int(mid)
    return redirect(url_for('openMessage', id=messageId))

def modifyReply(request):
    content = request.form["replyContent"]
    mid = request.form["messageId"]
    messageId = int(mid)
    m = Message.query.get(messageId)
    rid = request.form["replyId"]
    replyId = int(rid)
    r = Reply.query.get(replyId)
    if content != "":
        r.text = content
        db.session.add(r)
        db.session.commit()
        return render_template('viewMessageWindow.html', message=m)
    else:
        return render_template('editReplyWindow.html', reply=r, message=m, invalid_input=True)

def openReply(request):
    rid = request.args["rid"]
    replyId = int(rid)
    r = Reply.query.get(replyId)
    mid = request.args["mid"]
    messageId = int(mid)
    m = Message.query.get(messageId)
    return render_template('viewReplyWindow.html', reply=r, message=m)

def createReplyWindow(request):
    id = request.args["mid"]
    return render_template("createReplyWindow.html", messageId=id, invalid_input=False)

def editMessageWindow(request):
    id = request.args["id"]
    i = int(id)
    m = Message.query.get(i)
    users = Person.query.all() 
    return render_template('editMessageWindow.html', message=m, users=users, invalid_input=False)

def editReplyWindow(request):
    rid = request.args["rid"]
    replyId = int(rid)
    r = Reply.query.get(replyId)
    mid = request.args["mid"]
    messageId = int(mid)
    m = Message.query.get(messageId)
    return render_template('editReplyWindow.html', reply=r, message=m, invalid_input=False)
