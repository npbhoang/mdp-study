# Copyright (c) 2023 All Rights Reserved
# Generated code

from application import app
from flask import render_template, redirect, url_for, request
from flask_user import UserManager, user_registered, login_required, current_user
from dtm import db, Person, VISITOR, NORMAL, ADMIN,  Role, Purpose, Consent, PersonalData
from instrumentation import SecurityException, secure
from ptm import messageBoardPrivacyModel
import logging

@user_registered.connect_via(app)
def after_user_registered_hook(sender, user, **extra):
    role = Role.query.filter_by(name=NORMAL).one()
    user.role=role
    db.session.commit()

db.init_app(app)

# Silence passlib warning due to Flask-User not using the latest passlib version
logging.getLogger('passlib').setLevel(logging.ERROR)

with app.app_context():
    db.create_all()

    roles = Role.query.all()
    if len(roles) == 0:
        db.session.add(Role(name=VISITOR))
        db.session.add(Role(name=NORMAL))
        db.session.add(Role(name=ADMIN))
        db.session.commit()

    purposes = Purpose.query.all()
    if len(purposes) == 0:
        db.session.commit()
        
    personaldata = PersonalData.query.all()
    if len(personaldata) == 0:
        db.session.commit()

    def P(ls):
        def lazy():
            return list(map(lambda x: Purpose.query.filter_by(name=x).first(),ls))
        return lazy

user_manager = UserManager(app, db,Person)

# ENDPOINTS

def build_purpose_hierarchy(model):
    purpose_hierarchy = {}
    all_purposes = set()
    sub_purposes = set()

    # Build the hierarchy and track sub-purposes
    for p, rs, _, d in model:
        purpose = Purpose.query.filter_by(name=p.name).first()

        # Add the current purpose to the all_purposes set
        all_purposes.add(purpose.name)

        # Initialize the purpose in the hierarchy if not present
        if purpose.name not in purpose_hierarchy:
            purpose_hierarchy[purpose.name] = []

        # Get sub-purposes and track them
        subpurposes = purpose.subpurposes if hasattr(purpose, 'subpurposes') else []
        for subpurpose in subpurposes:
            # Add the subpurpose to the hierarchy under the parent purpose
            if subpurpose.name not in purpose_hierarchy[purpose.name]:
                purpose_hierarchy[purpose.name].append(subpurpose)

            # Ensure the sub-purpose is also initialized in the hierarchy
            if subpurpose.name not in purpose_hierarchy:
                purpose_hierarchy[subpurpose.name] = []

            # Track the sub-purpose
            sub_purposes.add(subpurpose.name)

    # Calculate top-level purposes as those that are not sub-purposes of any other purpose
    top_level_purposes = list(all_purposes - sub_purposes)

    return purpose_hierarchy, top_level_purposes

def find_personal_data(resource, subresource):
    pds = list(PersonalData.query.all())
    for pd in pds:
        if pd.resource == resource and pd.subresource == subresource:
            return pd
    return None

@app.get('/policy')
@login_required
@secure(db,P([]))
def policy():
    consents = Consent.query.filter_by(user_id=current_user.id).all()
    model = messageBoardPrivacyModel.model
    hierarchymodel, toplevel = build_purpose_hierarchy(model)
    newmodel = {}
    tmpmodel = {}
    # purpose, resource, conditional, description
    for p,rs,_,d in model:
        purpose = Purpose.query.filter_by(name=p.name).first()

        for r in rs:
            data = find_personal_data(r['resource'],r['subresource'])
            c = list(filter((lambda x: purpose in x.purposes and x.data == data),consents))
            a = r.get("subresource",r.get("ends", None))
            r = r["resource"]
            c = c[0] if len(c) > 0 else None
            if  tmpmodel.get((purpose,r,d,c),None) != None and a != None:
                tmpmodel[(purpose,r,d,c)].append(a)
            else:
                tmpmodel[(purpose,r,d,c)] = [a] if a != None else []

    
    for k in tmpmodel.keys():
        (p,r,d,c) = k
        a = tmpmodel[k]
        if p not in newmodel:
            newmodel[p] = [(a,r,d,c)]
        else:
            newmodel[p].append((a,r,d,c))
    return render_template('privacy.html', model=newmodel, hierarchymodel=hierarchymodel, toplevel=toplevel)

@app.route('/add_consent/<int:purposeid>', methods=['POST'])
@login_required
# @secure(db,P([]))
def add_consent(purposeid):
    data = request.get_json()
    pd = find_personal_data(data.get('personalData'), data.get('classData'))
    p = Purpose.query.filter_by(id=purposeid).first()
    c = Consent.query.filter_by(user_id=current_user.id,data=pd).first()
    
    if c is not None and p in c.purposes:
        return redirect(url_for('policy'))
    c = Consent(data=pd, user=current_user)
    c.purposes.append(p)
    db.session.add(c)
    db.session.commit()
    return redirect(url_for('policy'))

@app.route('/remove_consent/<int:purposeid>', methods=['DELETE'])
@login_required
# @secure(db,P([]))
def remove_consent(purposeid):
    data = request.get_json()
    pd = find_personal_data(data.get('personalData'), data.get('classData'))
    p = Purpose.query.filter_by(id=purposeid).first()
    c = Consent.query.filter_by(user_id=current_user.id,data=pd).first()
    
    if c is not None:
        db.session.delete(c)
        db.session.commit()
    return redirect(url_for('policy'))

@app.route('/error')
def error():
    msg = "You are not allowed to access this page: Not a User"
    return render_template('error.html', message = msg)

@app.route('/')
@secure(db,P([]))
def main():
    from project import main 
    return main(request)

@app.route('/createMessage', methods=['POST', 'GET'])
@secure(db,P([]))
def createMessage():
    from project import createMessage 
    return createMessage(request)


@app.route('/openMessage', methods=['POST', 'GET'])
@secure(db,P([]))
def openMessage():
    from project import openMessage 
    return openMessage(request)


@app.route('/modifyMessage', methods=['POST', 'GET'])
@secure(db,P([]))
def modifyMessage():
    from project import modifyMessage 
    return modifyMessage(request)


@app.route('/deleteMessage', methods=['POST', 'GET'])
@secure(db,P([]))
def deleteMessage():
    from project import deleteMessage 
    return deleteMessage(request)


@app.route('/createMessageWindow', methods=['POST', 'GET'])
@secure(db,P([]))
def createMessageWindow():
    from project import createMessageWindow 
    return createMessageWindow(request)


@app.route('/editMessageWindow', methods=['POST', 'GET'])
@secure(db,P([]))
def editMessageWindow():
    from project import editMessageWindow 
    return editMessageWindow(request)


@app.route('/createReply', methods=['POST', 'GET'])
@secure(db,P([]))
def createReply():
    from project import createReply 
    return createReply(request)


@app.route('/openReply', methods=['POST', 'GET'])
@secure(db,P([]))
def openReply():
    from project import openReply 
    return openReply(request)


@app.route('/modifyReply', methods=['POST', 'GET'])
@secure(db,P([]))
def modifyReply():
    from project import modifyReply 
    return modifyReply(request)


@app.route('/deleteReply', methods=['POST', 'GET'])
@secure(db,P([]))
def deleteReply():
    from project import deleteReply 
    return deleteReply(request)


@app.route('/createReplyWindow', methods=['POST', 'GET'])
@secure(db,P([]))
def createReplyWindow():
    from project import createReplyWindow 
    return createReplyWindow(request)


@app.route('/editReplyWindow', methods=['POST', 'GET'])
@secure(db,P([]))
def editReplyWindow():
    from project import editReplyWindow 
    return editReplyWindow(request)

