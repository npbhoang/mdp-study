# Copyright (c) 2023 All Rights Reserved
# Generated code

from security_model import SecurityModel
from model import Action, Constraint
from enum import auto, Enum
import dtm

class FullAccess(SecurityModel):
    @classmethod
    def permit(cls, r, attr, act, self, caller, value=None):
        def __securitycheck__():
            return True
        return __securitycheck__()


# Security model

class messageBoardSecurityModel(SecurityModel):
    class Role(Enum):
        VISITOR = auto()
        NORMAL = auto()
        ADMIN = auto()
        
        def isSubRole(self, obj):
            return (False)

        def __le__ (self,obj):
            if isinstance(obj,messageBoardSecurityModel.Role):
                if SecurityModel.closure == {}:
                    SecurityModel.close(messageBoardSecurityModel.Role)
                return self in SecurityModel.closure and obj in SecurityModel.closure[self]
            else:
                raise ValueError
    
    model = {Role.VISITOR: {'Person': {'role': {Action.read: Constraint.fullAccess, Action.update: Constraint.fullAccess}, 'replies': {Action.read: Constraint.fullAccess, Action.add: Constraint.fullAccess, Action.remove: Constraint.fullAccess}, 'name': {Action.update: Constraint.fullAccess, Action.read: Constraint.fullAccess}, 'messages': {Action.read: Constraint.fullAccess, Action.add: Constraint.fullAccess, Action.remove: Constraint.fullAccess}, 'Person': {Action.delete: Constraint.fullAccess, Action.create: Constraint.fullAccess}}, 'Message': {'messageOwner': {Action.update: Constraint.fullAccess, Action.read: Constraint.fullAccess}, 'title': {Action.read: Constraint.fullAccess, Action.update: Constraint.fullAccess}, 'messageReplies': {Action.read: Constraint.fullAccess, Action.add: Constraint.fullAccess, Action.remove: Constraint.fullAccess}, 'text': {Action.update: Constraint.fullAccess, Action.read: Constraint.fullAccess}, 'Message': {Action.delete: Constraint.fullAccess, Action.create: Constraint.fullAccess}}, 'Reply': {'Reply': {Action.delete: Constraint.fullAccess, Action.create: Constraint.fullAccess}, 'message': {Action.update: Constraint.fullAccess, Action.read: Constraint.fullAccess}, 'text': {Action.update: Constraint.fullAccess, Action.read: Constraint.fullAccess}, 'replyOwner': {Action.update: Constraint.fullAccess, Action.read: Constraint.fullAccess}}}, Role.NORMAL: {'Person': {'role': {Action.read: Constraint.fullAccess, Action.update: Constraint.fullAccess}, 'replies': {Action.read: Constraint.fullAccess, Action.add: Constraint.fullAccess, Action.remove: Constraint.fullAccess}, 'name': {Action.update: Constraint.fullAccess, Action.read: Constraint.fullAccess}, 'messages': {Action.read: Constraint.fullAccess, Action.add: Constraint.fullAccess, Action.remove: Constraint.fullAccess}, 'Person': {Action.delete: Constraint.fullAccess, Action.create: Constraint.fullAccess}}, 'Message': {'messageOwner': {Action.update: Constraint.fullAccess, Action.read: Constraint.fullAccess}, 'title': {Action.read: Constraint.fullAccess, Action.update: Constraint.fullAccess}, 'messageReplies': {Action.read: Constraint.fullAccess, Action.add: Constraint.fullAccess, Action.remove: Constraint.fullAccess}, 'text': {Action.update: Constraint.fullAccess, Action.read: Constraint.fullAccess}, 'Message': {Action.delete: Constraint.fullAccess, Action.create: Constraint.fullAccess}}, 'Reply': {'Reply': {Action.delete: Constraint.fullAccess, Action.create: Constraint.fullAccess}, 'message': {Action.update: Constraint.fullAccess, Action.read: Constraint.fullAccess}, 'text': {Action.update: Constraint.fullAccess, Action.read: Constraint.fullAccess}, 'replyOwner': {Action.update: Constraint.fullAccess, Action.read: Constraint.fullAccess}}}, Role.ADMIN: {'Person': {'role': {Action.read: Constraint.fullAccess, Action.update: Constraint.fullAccess}, 'replies': {Action.read: Constraint.fullAccess, Action.add: Constraint.fullAccess, Action.remove: Constraint.fullAccess}, 'name': {Action.update: Constraint.fullAccess, Action.read: Constraint.fullAccess}, 'messages': {Action.read: Constraint.fullAccess, Action.add: Constraint.fullAccess, Action.remove: Constraint.fullAccess}, 'Person': {Action.delete: Constraint.fullAccess, Action.create: Constraint.fullAccess}}, 'Message': {'messageOwner': {Action.update: Constraint.fullAccess, Action.read: Constraint.fullAccess}, 'title': {Action.read: Constraint.fullAccess, Action.update: Constraint.fullAccess}, 'messageReplies': {Action.read: Constraint.fullAccess, Action.add: Constraint.fullAccess, Action.remove: Constraint.fullAccess}, 'text': {Action.update: Constraint.fullAccess, Action.read: Constraint.fullAccess}, 'Message': {Action.delete: Constraint.fullAccess, Action.create: Constraint.fullAccess}}, 'Reply': {'Reply': {Action.delete: Constraint.fullAccess, Action.create: Constraint.fullAccess}, 'message': {Action.update: Constraint.fullAccess, Action.read: Constraint.fullAccess}, 'text': {Action.update: Constraint.fullAccess, Action.read: Constraint.fullAccess}, 'replyOwner': {Action.update: Constraint.fullAccess, Action.read: Constraint.fullAccess}}}}
    
messageBoardSecurityModel.validate()