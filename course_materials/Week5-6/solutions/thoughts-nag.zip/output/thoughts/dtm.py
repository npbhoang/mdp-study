# Copyright (c) 2025 All Rights Reserved
# Generated code

from application import app
from flask_user import UserMixin, current_user
from stm import thoughtsSecurityModel
from ptm import thoughtsPrivacyModel
from ocl.ocl import OCLTerm
from sqlalchemy import UniqueConstraint

# Initialize SQLAlchemy database instance
from flask_sqlalchemy import SQLAlchemy
db = SQLAlchemy()

# Set up deletion interception for security and privacy models
from instrumentation import Secure, setup_deletion_interception
setup_deletion_interception(db.session,thoughtsSecurityModel,thoughtsPrivacyModel)

# =========================
# Role Constants
# =========================
UNAUTHENTICATED_ROLE = "ANONYMOUS"
ANONYMOUS = "ANONYMOUS"
NORMALUSER = "NORMALUSER"



# =========================
# Purpose Constants
# =========================
DISPLAY = "DISPLAY"
VOTE = "VOTE"
ADD_NEW_THOUGHT = "ADD_NEW_THOUGHT"



with app.app_context():

    # =========================
    # Association between Consent and Purpose
    # =========================
    # Many-to-many relationship between Consent and Purpose
    consentedpurposes = db.Table('consentedpurposes',
            db.Column('consent_id', db.Integer, db.ForeignKey('consent.id'), nullable=False, primary_key=True),
            db.Column('purpose_id', db.Integer, db.ForeignKey('purpose.id'), nullable=False, primary_key=True)
    )
    # =========================
    # Association between Thought and Person
    # =========================
    
    class person_thought(db.Model):
            
        id = db.Column(db.Integer, primary_key=True)
        created_id = db.Column(db.Integer(), db.ForeignKey('thought.id'), unique=True)
        createdBy_id = db.Column(db.Integer(), db.ForeignKey('person.id'))
        created = db.relationship('Thought', back_populates='person_thought', uselist=False)
        createdBy = db.relationship('Person', back_populates='person_thought', uselist=False)
    
    # =========================
    # Association between Thought and Person
    # =========================
    
    class vote(db.Model):
            
        id = db.Column(db.Integer, primary_key=True)
        voted_id = db.Column(db.Integer(), db.ForeignKey('thought.id'))
        votedBy_id = db.Column(db.Integer(), db.ForeignKey('person.id'))
        voted = db.relationship('Thought', back_populates='vote', uselist=False)
        votedBy = db.relationship('Person', back_populates='vote', uselist=False)
    
    

    # ENTITIES
    
    # =========================
    # Entity Person (User class)
    # =========================
    @Secure(thoughtsSecurityModel,thoughtsPrivacyModel)
    class Person(db.Model,UserMixin,OCLTerm):

        #Association-end type classes
        class createdList(list):
            
            def __init__(self,this):
                self._this = this
                super().__init__()
            
            def __init__(self,this, __iterable):
                self._this = this
                super().__init__(__iterable)
            
            def append(self,e):
                v = person_thought(createdBy=self._this,created=e)
                db.session.add(v)
                super().append(e)
            
            def remove(self,e):
                super().remove(e)
                v = person_thought.query.filter_by(createdBy=self._this,created=e).first()
                db.session.delete(v)
        class votedList(list):
            
            def __init__(self,this):
                self._this = this
                super().__init__()
            
            def __init__(self,this, __iterable):
                self._this = this
                super().__init__(__iterable)
            
            def append(self,e):
                v = vote(votedBy=self._this,voted=e)
                db.session.add(v)
                super().append(e)
            
            def remove(self,e):
                super().remove(e)
                v = vote.query.filter_by(votedBy=self._this,voted=e).first()
                db.session.delete(v)
        

        #Attributes
        id = db.Column(db.Integer, primary_key=True)
        active = db.Column('is_active', db.Boolean(), nullable=False, server_default='1')
        roles = db.relationship('Role', secondary='user_roles')
        username = db.Column(db.String(100, collation='NOCASE'), nullable=False, unique=True)
        password = db.Column(db.String(255), nullable=False, server_default='')
        name = db.Column(db.String(100, collation="NOCASE"))
        

        # Association ends
        person_thought = db.relationship('person_thought', cascade="all, delete-orphan", back_populates='createdBy')
        
        @property
        def created(self):    
            return Person.createdList(self, [x.created for x in self.person_thought]) 
        
        vote = db.relationship('vote', cascade="all, delete-orphan", back_populates='votedBy')
        
        @property
        def voted(self):    
            return Person.votedList(self, [x.voted for x in self.vote]) 
        
        @property
        def owner(self):
            return self
        @property
        def role(self):
            return self.roles[0]
        
        @role.setter
        def role(self,r):
            self.roles = [r]
        
        @property
        def is_authenticated(self):
            return True
        
        def __eq__(self, obj):
            return isinstance(obj,UserMixin) and self.id == obj.id 
        
        @classmethod
        def allInstances(cls):
            return cls.query.all() if hasattr(cls,'query') else super().allInstances()

        
        @classmethod
        def add_thought(cls, request):
            from project import add_thought
            return add_thought(request)
        
        @classmethod
        def delete_thought(cls, request):
            from project import delete_thought
            return delete_thought(request)
        
        @classmethod
        def vote_thought(cls, request):
            from project import vote_thought
            return vote_thought(request)
        

    # =========================
    # Entity Role
    # =========================
    class Role(db.Model,OCLTerm):
        id = db.Column(db.Integer(), primary_key=True)
        name = db.Column(db.String(50), unique=True)

        @staticmethod
        def getAuthenticatedRoles():
            return Role.query.filter(Role.name != UNAUTHENTICATED_ROLE).all()

        @classmethod
        def _get_role(cls, role_name):
            return cls.query.filter_by(name=role_name).first()
            
        @classmethod
        @property
        def ANONYMOUS(cls):
            return cls._get_role('ANONYMOUS')

        @classmethod
        @property
        def NORMALUSER(cls):
            return cls._get_role('NORMALUSER')

        
    
        @classmethod
        def allInstances(cls):
            return cls.query.all() if hasattr(cls,'query') else super().allInstances()
        
    # =========================
    # Entity UserRoles
    # =========================
    class UserRoles(db.Model):
        id = db.Column(db.Integer(), primary_key=True)
        user_id = db.Column(db.Integer(), db.ForeignKey('person.id'), unique=True)
        role_id = db.Column(db.Integer(), db.ForeignKey('role.id'))

        @classmethod
        def allInstances(cls):
            return cls.query.all() if hasattr(cls,'query') else super().allInstances()
    
    
    

    # =========================
    # Entity Thought
    # =========================
    @Secure(thoughtsSecurityModel,thoughtsPrivacyModel)
    class Thought(db.Model,OCLTerm):
        
        # Association-end type classes
        class createdByList(list):
            
            def __init__(self,this):
                self._this = this
                super().__init__()
            
            def __init__(self,this, __iterable):
                self._this = this
                super().__init__(__iterable)
            
            def append(self,e):
                v = person_thought(created=self._this,createdBy=e)
                db.session.add(v)
                super().append(e)
            
            def remove(self,e):
                super().remove(e)
                v = person_thought.query.filter_by(created=self._this,createdBy=e).first()
                db.session.delete(v)
        class votedByList(list):
            
            def __init__(self,this):
                self._this = this
                super().__init__()
            
            def __init__(self,this, __iterable):
                self._this = this
                super().__init__(__iterable)
            
            def append(self,e):
                v = vote(voted=self._this,votedBy=e)
                db.session.add(v)
                super().append(e)
            
            def remove(self,e):
                super().remove(e)
                v = vote.query.filter_by(voted=self._this,votedBy=e).first()
                db.session.delete(v)
        

        # Attributes
        id = db.Column(db.Integer, primary_key=True)
        content = db.Column(db.String(100, collation="NOCASE"))
        

        # Association ends
        person_thought = db.relationship('person_thought', cascade="all, delete-orphan", back_populates='created', uselist=False)
        @property
        def createdBy(self):
            return self.person_thought.createdBy if self.person_thought else None

        @createdBy.setter
        def createdBy(self, value):
            if self.person_thought:
                self.person_thought.createdBy = value
            else:
                v = person_thought(created=self,createdBy=value)
                db.session.add(v)
            
        vote = db.relationship('vote', cascade="all, delete-orphan", back_populates='voted')
        @property
        def votedBy(self):
            
            return Thought.votedByList(self, [x.votedBy for x in self.vote]) 
            
        owner_id = db.Column(db.Integer, db.ForeignKey('person.id'), nullable=False)
        owner = db.relationship('Person', foreign_keys=owner_id, backref='personal')
        def __init__(self, **kwargs):
            super(Thought, self).__init__(**kwargs)
            self.owner=current_user
            db.session.commit()
        
    
        @classmethod
        def allInstances(cls):
            return cls.query.all() if hasattr(cls,'query') else super().allInstances()

        
        @classmethod
        def getAllThoughts(cls, request):
            from project_aux import getAllThoughts
            return getAllThoughts(request)
        

    
    
    
    
    
    
    

    # =========================
    # Entity Purpose
    # =========================
    class Purpose(db.Model,OCLTerm):
        id = db.Column(db.Integer(), primary_key=True)
        name = db.Column(db.String(50), unique=True)
        parent_id = db.Column(db.Integer, db.ForeignKey('purpose.id'))
        subpurposes = db.relationship('Purpose')

        def get_subpurposes_names(self):
            ret = []
            for sp in self.subpurposes:
                ret.append(sp.name)
                ret.extend(sp.get_subpurposes_names())  # Recursively get sub-purpose names
            return ret

        # consents = db.relationship('Consent', secondary=consentedpurposes, lazy='subquery',
        # back_populates='purposes')

        def __hash__(self):
            return hash(self.id)
        
        @classmethod
        def allInstances(cls):
            return cls.query.all() if hasattr(cls,'query') else super().allInstances()

    # =========================
    # Entity PersonalData
    # =========================
    class PersonalData(db.Model,OCLTerm):
        id = db.Column(db.Integer(), primary_key=True)
        resource = db.Column(db.String(100))
        subresource = db.Column(db.String(100))
        __table_args__ = (
            UniqueConstraint('resource', 'subresource', name='resource_subresource_uc'),
        )

        @classmethod
        def allInstances(cls):
            return cls.query.all() if hasattr(cls,'query') else super().allInstances()

    # =========================
    # Entity Consent
    # =========================
    class Consent(db.Model,OCLTerm):
        id = db.Column(db.Integer(), primary_key=True)
        user_id = db.Column(db.Integer, db.ForeignKey('person.id'), nullable=False)
        user = db.relationship('Person', foreign_keys=user_id, backref='consents')
        data_id = db.Column(db.Integer, db.ForeignKey('personal_data.id'), nullable=False)
        data = db.relationship('PersonalData', foreign_keys=data_id)
        purposes = db.relationship('Purpose', secondary=consentedpurposes, lazy='subquery')#, back_populates='consents')

        def __hash__(self):
            return hash(self.id)
        
        @classmethod
        def allInstances(cls):
            return cls.query.all() if hasattr(cls,'query') else super().allInstances()
        

