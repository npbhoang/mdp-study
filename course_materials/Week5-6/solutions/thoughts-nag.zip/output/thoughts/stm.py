# Copyright (c) 2025 All Rights Reserved
# Generated code

from security_model import SecurityModel
from model import Action, Constraint
from enum import auto, Enum
import dtm

class FullAccess(SecurityModel):
    @classmethod
    def permit(cls, r, attr, act, self, caller, value=None):
        def __securitycheck__():
            return True
        return __securitycheck__()


# Security model

class thoughtsSecurityModel(SecurityModel):
    class Role(Enum):
        ANONYMOUS = auto()
        NORMALUSER = auto()
        
        def isSubRole(self, obj):
            return (self == self.ANONYMOUS and obj == self.NORMALUSER or 
                    False)

        def __le__ (self,obj):
            if isinstance(obj,thoughtsSecurityModel.Role):
                if SecurityModel.closure == {}:
                    SecurityModel.close(thoughtsSecurityModel.Role)
                return self in SecurityModel.closure and obj in SecurityModel.closure[self]
            else:
                raise ValueError
    
    model = {Role.ANONYMOUS: {'Person': {}, 'Thought': {'content': {Action.read: Constraint.fullAccess}}}, Role.NORMALUSER: {'Person': {'name': {Action.read: Constraint.fullAccess, Action.update: lambda value=None, caller=None, self=None: self == caller}, 'voted': {Action.add: lambda value= None, caller= None, self= None: value.dot('votedBy').select((lambda v: v == caller)).size() < 3 and self != caller}}, 'Thought': {'Thought': {Action.create: Constraint.fullAccess, Action.delete: lambda self= None, caller= None: self.dot('createdBy') == caller}, 'content': {Action.read: Constraint.fullAccess, Action.update: lambda value=None, caller=None, self=None: self.dot('createdBy') == None or self.dot('createdBy') == caller}, 'votedBy': {Action.read: Constraint.fullAccess, Action.add: lambda value=None, caller=None, self=None: self.dot('votedBy').select(lambda v: v == caller).size() < 3 and self.dot('createdBy') != caller}, 'createdBy': {Action.read: Constraint.fullAccess, Action.update: lambda self= None, value= None, caller= None: self.dot('createdBy') == None and value == caller}}}}
    
thoughtsSecurityModel.validate()