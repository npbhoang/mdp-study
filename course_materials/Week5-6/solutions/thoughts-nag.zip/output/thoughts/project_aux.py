from dtm import Thought, vote

def getAllThoughts(args):
    return Thought.query.all()