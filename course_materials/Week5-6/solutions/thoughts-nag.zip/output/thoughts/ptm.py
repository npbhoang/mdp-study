# Copyright (c) 2025 All Rights Reserved
# Generated code

from model import Action, Constraint
from enum import auto, Enum
from privacy_model import PrivacyModel
import dtm

class thoughtsPrivacyModel(PrivacyModel):

    # Extensible model (default: nothing declared)

    class Purpose(Enum):
        
        DISPLAY = auto()
        VOTE = auto()
        ADD_NEW_THOUGHT = auto()
        
        

        def get_subpurposes_names(self):
            ret = []
            for sp in purpose_hierarchy[self]:
                ret.append(sp.name)
                ret.extend(sp.get_subpurposes_names())
            return ret

    personaldata = [
        {'resource': 'Person', 'subresource': 'created'},
        {'resource': 'Person', 'subresource': 'voted'},
        {'resource': 'Person', 'subresource': 'name'},
        {'resource': 'Person', 'subresource': 'role'},
        {'resource': 'Thought', 'subresource': 'createdBy'},
        {'resource': 'Thought', 'subresource': 'votedBy'}
        ]
        
    model = [(Purpose.VOTE, [{'resource': 'Person', 'subresource': 'voted'}], Constraint.fullAccess, 'true'), (Purpose.VOTE, [{'resource': 'Thought', 'subresource': 'votedBy'}], Constraint.fullAccess, 'true'), (Purpose.ADD_NEW_THOUGHT, [{'resource': 'Person', 'subresource': 'created'}], Constraint.fullAccess, 'true'), (Purpose.ADD_NEW_THOUGHT, [{'resource': 'Thought', 'subresource': 'createdBy'}], Constraint.fullAccess, 'true'), (Purpose.DISPLAY, [{'resource': 'Person', 'subresource': 'name'}], Constraint.fullAccess, 'true'), (Purpose.DISPLAY, [{'resource': 'Thought', 'subresource': 'votedBy'}], Constraint.fullAccess, 'true'), (Purpose.DISPLAY, [{'resource': 'Thought', 'subresource': 'createdBy'}], Constraint.fullAccess, 'true')]

purpose_hierarchy = {
    thoughtsPrivacyModel.Purpose.DISPLAY: [
    ], 
    thoughtsPrivacyModel.Purpose.VOTE: [
    ], 
    thoughtsPrivacyModel.Purpose.ADD_NEW_THOUGHT: [
    ]
}

thoughtsPrivacyModel.validate()