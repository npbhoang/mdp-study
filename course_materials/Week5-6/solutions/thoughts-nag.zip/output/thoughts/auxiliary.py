# Copyright (c) 2025 All Rights Reserved
# Generated code

from instrumentation import secure
from dtm import Person, Thought, db
from app import P





@secure(db,P([]))
def getAllThoughts(args={}):
    from project_aux import getAllThoughts 
    return Thought.getAllThoughts(args)

