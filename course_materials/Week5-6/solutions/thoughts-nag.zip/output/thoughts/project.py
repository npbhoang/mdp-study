# Copyright (c) 2025 All Rights Reserved
# Generated code

from flask import render_template, redirect, url_for
from flask_user import current_user
from dtm import Thought, vote
from app import db
from auxiliary import getAllThoughts

def main(request):
    thoughts=getAllThoughts()
    return render_template('main.html', table=thoughts, user=current_user)

def add_thought(request):
    content = request.form["thought"]
    if content != "":
        t = Thought()
        t.content = content
        t.createdBy = current_user
        db.session.add(t)
        db.session.commit()
        return redirect(url_for('main'))
    else:
        thoughts = Thought.query.all()
        return render_template('main.html', table=thoughts, invalid_input=True)

def delete_thought(request):
    id = request.args["id"]
    i = int(id)
    t = Thought.query.get(i)
    if t != None:
        db.session.delete(t)
        db.session.commit()
    return redirect(url_for('main'))

def vote_thought(request):
    id = request.args["id"]
    i = int(id)
    t = Thought.query.get(i)
    c = current_user
    if t != None and c != None:
        t.votedBy.append(c)
        # c.voted.append(t)
        db.session.commit()
    return redirect(url_for('main'))


