# Copyright (c) 2025 All Rights Reserved
# Generated code

from application import app
from flask import render_template, redirect, url_for, request, jsonify
from flask_user import UserManager, user_registered, login_required, current_user
from dtm import Person, Thought, db
from dtm import ANONYMOUS, NORMALUSER, Role
from dtm import DISPLAY, VOTE, ADD_NEW_THOUGHT, Purpose, Consent, PersonalData
from instrumentation import SecurityException, secure
from ptm import thoughtsPrivacyModel
import logging

@user_registered.connect_via(app)
def after_user_registered_hook(sender, user, **extra):
    role = Role.query.filter_by(name=NORMALUSER).one()
    user.role=role
    db.session.commit()

db.init_app(app)

# Silence passlib warning due to Flask-User not using the latest passlib version
logging.getLogger('passlib').setLevel(logging.ERROR)

with app.app_context():
    db.create_all()

    roles = Role.query.all()
    if len(roles) == 0:
        db.session.add(Role(name=ANONYMOUS))
        db.session.add(Role(name=NORMALUSER))
        db.session.commit()

    purposes = Purpose.query.all()
    if len(purposes) == 0:
        db.session.add(Purpose(name=DISPLAY))
        db.session.add(Purpose(name=VOTE))
        db.session.add(Purpose(name=ADD_NEW_THOUGHT))
        db.session.commit()
        p = Purpose.query.filter_by(name=DISPLAY).first()
        db.session.commit()
        p = Purpose.query.filter_by(name=VOTE).first()
        db.session.commit()
        p = Purpose.query.filter_by(name=ADD_NEW_THOUGHT).first()
        db.session.commit()
        
    personaldata = PersonalData.query.all()
    if len(personaldata) == 0:
        db.session.add(PersonalData(resource='Person', subresource='created'))
        db.session.add(PersonalData(resource='Person', subresource='voted'))
        db.session.add(PersonalData(resource='Person', subresource='name'))
        db.session.add(PersonalData(resource='Person', subresource='role'))
        db.session.add(PersonalData(resource='Thought', subresource='createdBy'))
        db.session.add(PersonalData(resource='Thought', subresource='votedBy'))
        db.session.commit()

    def P(ls):
        def lazy():
            return list(map(lambda x: Purpose.query.filter_by(name=x).first(),ls))
        return lazy

user_manager = UserManager(app, db,Person)

# ENDPOINTS

def build_purpose_hierarchy(model):
    purpose_hierarchy = {}
    all_purposes = set()
    sub_purposes = set()
    for p, rs, _, d in model:
        purpose = Purpose.query.filter_by(name=p.name).first()
        all_purposes.add(purpose.name)
        if purpose.name not in purpose_hierarchy:
            purpose_hierarchy[purpose.name] = []
        subpurposes = purpose.subpurposes if hasattr(purpose, 'subpurposes') else []
        for subpurpose in subpurposes:
            if subpurpose.name not in purpose_hierarchy[purpose.name]:
                purpose_hierarchy[purpose.name].append(subpurpose)
            if subpurpose.name not in purpose_hierarchy:
                purpose_hierarchy[subpurpose.name] = []
            sub_purposes.add(subpurpose.name)
    top_level_purposes = list(all_purposes - sub_purposes)
    return purpose_hierarchy, top_level_purposes

def find_personal_data(resource, subresource):
    pds = list(PersonalData.query.all())
    for pd in pds:
        if pd.resource == resource and pd.subresource == subresource:
            return pd
    return None

@app.get('/policy')
@login_required
@secure(db,P([]))
def policy():
    consents = Consent.query.filter_by(user_id=current_user.id).all()
    model = thoughtsPrivacyModel.model
    hierarchymodel, toplevel = build_purpose_hierarchy(model)
    newmodel = {}
    tmpmodel = {}
    for p,rs,_,d in model:
        purpose = Purpose.query.filter_by(name=p.name).first()

        for r in rs:
            data = find_personal_data(r['resource'],r['subresource'])
            c = list(filter((lambda x: purpose in x.purposes and x.data == data),consents))
            a = r.get("subresource",r.get("ends", None))
            r = r["resource"]
            c = c[0] if len(c) > 0 else None
            if  tmpmodel.get((purpose,r,d,c),None) != None and a != None:
                tmpmodel[(purpose,r,d,c)].append(a)
            else:
                tmpmodel[(purpose,r,d,c)] = [a] if a != None else []

    for k in tmpmodel.keys():
        (p,r,d,c) = k
        a = tmpmodel[k]
        if p not in newmodel:
            newmodel[p] = [(a,r,d,c)]
        else:
            newmodel[p].append((a,r,d,c))
    return render_template('privacy.html', model=newmodel, hierarchymodel=hierarchymodel, toplevel=toplevel)

@app.route('/add_consent/<int:purposeid>', methods=['POST'])
@login_required
# @secure(db,P([]))
def add_consent(purposeid):
    data = request.get_json()
    pd = find_personal_data(data.get('personalData'), data.get('classData'))
    p = Purpose.query.filter_by(id=purposeid).first()
    c = Consent.query.filter_by(user_id=current_user.id,data=pd).first()
    
    if c is not None and p in c.purposes:
        return redirect(url_for('policy'))
    c = Consent(data=pd, user=current_user)
    c.purposes.append(p)
    db.session.add(c)
    db.session.commit()
    return redirect(url_for('policy'))

@app.route('/remove_consent/<int:purposeid>', methods=['DELETE'])
@login_required
# @secure(db,P([]))
def remove_consent(purposeid):
    data = request.get_json()
    pd = find_personal_data(data.get('personalData'), data.get('classData'))
    p = Purpose.query.filter_by(id=purposeid).first()
    cs = Consent.query.filter_by(user_id=current_user.id,data=pd).all()

    for c in cs:
        if p in c.purposes:
            db.session.delete(c)
    db.session.commit()

    return jsonify({ 'success': True })
def error():
    msg = "You are not allowed to access this page: Not a User"
    return render_template('error.html', message = msg)

@app.route('/')
@secure(db,P(['DISPLAY']))
def main():
    from project import main 
    return main(request)

@app.route('/add_thought', methods=['POST', 'GET'])
@secure(db,P(['ADD_NEW_THOUGHT']))
def add_thought():
    return Person.add_thought(request)


@app.route('/delete_thought', methods=['POST', 'GET'])
@secure(db,P([]))
def delete_thought():
    return Person.delete_thought(request)


@app.route('/vote_thought', methods=['POST', 'GET'])
@secure(db,P(['VOTE']))
def vote_thought():
    return Person.vote_thought(request)


