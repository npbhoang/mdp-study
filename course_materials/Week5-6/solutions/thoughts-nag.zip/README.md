# NuActionGUI

## Table of Contents
- [NuActionGUI](#nuactiongui)
  - [Table of Contents](#table-of-contents)
  - [DataMinimizer Container](#dataminimizer-container)
    - [Requirements](#requirements)
    - [Usage](#usage)
  - [License](#license)

## DataMinimizer Container
### Requirements
- [Docker](https://www.docker.com/)
- OCL-py (already included in this archive under `ocl-py/`)

### Usage

1. **Prerequisites:**
   - Ensure you have [Docker](https://www.docker.com/) installed.

2. **Start the container:**
   - Open a terminal and run:
     ```powershell
     docker compose up --detach
     ```
   - This will start the `nag` container instance.

3. (Optional) **Regenerate parsers:**
   - This step is run automatically on container creation. It is generally safe to skip this step.
   - The parsers in Python are generated automatically using ANTLR4 from the grammar (.g4) files.
   - If the grammar files are modified, or if the Python parsers are deleted, regenerate the parsers using:
     ```powershell
     make grammars
     ```

4. **Run tests:**
   - To verify your setup, run the test suite:
     ```bash
     make test
     ```

5. **Run the transformation:**
   - Data (.dtm), security (.stm) and privacy (.ptm) models are grouped together into a project, which describes one "application".
   - Place each project as its own folder under the `models` directory.
     - Example: the models of a project `Foo` should be accessible as `models/Foo/main.dtm`, `models/Foo/main.stm` and so on.
   - To compile and (re)generate security and privacy aspects of a project:
     ```powershell
     python3 src/generate.py -p <project-folder> -o <output-folder> -re
     ```
     - Example: `python3 src/generate.py -p Foo` compiles the models of project `Foo` and (re)generates the application at `output/Foo` by default.
     - Note: if regenerating, you may have to remove the current instance of the database, located in `/app/<output-folder>/<project-folder>/instance/`.
  
6. **Run a project:**
   - Go to the corresponding `/app/<output-folder>/<project-folder>` directory and run:
     ```powershell
     flask --app app.py run --host=0.0.0.0
     ```
   - The app should be reachable from your local machine at `localhost:5000`.

## License

This project is licensed under the MIT License. See [LICENSE](LICENSE) for details:

```
MIT License

Copyright (c) 2025 ETH Zurich

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
```
